# Lottery Checker Online

A full-stack lottery result checker application built with **Node.js + Express + MongoDB** and **HTML + CSS + JavaScript**.

## Features

✅ **User Authentication** - Secure signup and login with JWT  
✅ **Lottery Result Checker** - Search results by mobile number or ticket number  
✅ **Admin Panel** - Add, view, and delete lottery results  
✅ **User Management** - View all registered users (Admin only)  
✅ **Mobile Responsive** - Works perfectly on all devices  
✅ **Secure API** - Protected routes with authentication middleware

## Project Structure
