const express = require('express');
const Lottery = require('../models/Lottery');
const { auth } = require('../middleware/auth');
const router = express.Router();

// Check lottery result
router.post('/check', auth, async (req, res) => {
  try {
    const { mobileNumber, ticketNumber } = req.body;

    if (!mobileNumber && !ticketNumber) {
      return res.status(400).json({ message: 'Provide mobile number or ticket number' });
    }

    let query = {};
    if (mobileNumber) query.mobileNumber = mobileNumber;
    if (ticketNumber) query.ticketNumber = ticketNumber;

    const results = await Lottery.find(query);

    if (results.length === 0) {
      return res.json({ message: 'No results found', results: [] });
    }

    res.json({
      message: 'Results found',
      results,
      count: results.length
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get all lottery results (user's own)
router.get('/my-results', auth, async (req, res) => {
  try {
    const results = await Lottery.find({});
    res.json({ results });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
