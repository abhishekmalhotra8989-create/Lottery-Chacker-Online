const express = require('express');
const Lottery = require('../models/Lottery');
const User = require('../models/User');
const { adminAuth } = require('../middleware/auth');
const router = express.Router();

// Add lottery result (Admin only)
router.post('/add-result', adminAuth, async (req, res) => {
  try {
    const { ticketNumber, mobileNumber, name, amount, drawDate } = req.body;

    // Check if ticket already exists
    let lottery = await Lottery.findOne({ ticketNumber });
    if (lottery) {
      return res.status(400).json({ message: 'Ticket already exists' });
    }

    lottery = new Lottery({
      ticketNumber,
      mobileNumber,
      name,
      amount,
      drawDate,
      status: 'won'
    });

    await lottery.save();
    res.status(201).json({ message: 'Lottery result added successfully', lottery });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get all lottery results (Admin only)
router.get('/all-results', adminAuth, async (req, res) => {
  try {
    const results = await Lottery.find({}).sort({ createdAt: -1 });
    res.json({ 
      message: 'All lottery results',
      count: results.length,
      results 
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Delete lottery result (Admin only)
router.delete('/result/:id', adminAuth, async (req, res) => {
  try {
    const result = await Lottery.findByIdAndDelete(req.params.id);
    if (!result) {
      return res.status(404).json({ message: 'Result not found' });
    }
    res.json({ message: 'Result deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Update lottery result (Admin only)
router.put('/result/:id', adminAuth, async (req, res) => {
  try {
    const { ticketNumber, mobileNumber, name, amount, drawDate, status } = req.body;
    
    let result = await Lottery.findById(req.params.id);
    if (!result) {
      return res.status(404).json({ message: 'Result not found' });
    }

    if (ticketNumber) result.ticketNumber = ticketNumber;
    if (mobileNumber) result.mobileNumber = mobileNumber;
    if (name) result.name = name;
    if (amount) result.amount = amount;
    if (drawDate) result.drawDate = drawDate;
    if (status) result.status = status;

    await result.save();
    res.json({ message: 'Result updated successfully', result });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get all users (Admin only)
router.get('/users', adminAuth, async (req, res) => {
  try {
    const users = await User.find({}).select('-password');
    res.json({ 
      message: 'All users',
      count: users.length,
      users 
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

module.exports = router;
