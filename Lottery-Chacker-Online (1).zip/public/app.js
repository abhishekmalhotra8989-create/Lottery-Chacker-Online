const API_URL = 'http://localhost:5000/api';
let token = localStorage.getItem('token');
let currentUser = localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')) : null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  updateNavigation();
  if (token) {
    showChecker();
  } else {
    showHome();
  }
});

// Navigation functions
function showHome() {
  hideAllSections();
  document.getElementById('home').classList.add('active');
}

function showAuth() {
  hideAllSections();
  document.getElementById('auth').classList.add('active');
}

function showChecker() {
  if (!token) {
    showMessage('Please login first', 'error');
    showAuth();
    return;
  }
  hideAllSections();
  document.getElementById('checker').classList.add('active');
}

function showAdmin() {
  if (!token || !currentUser.isAdmin) {
    showMessage('Admin access required', 'error');
    return;
  }
  hideAllSections();
  document.getElementById('admin').classList.add('active');
}

function hideAllSections() {
  document.querySelectorAll('.section').forEach(section => {
    section.classList.remove('active');
  });
}

function updateNavigation() {
  const authBtn = document.getElementById('authBtn');
  const logoutBtn = document.getElementById('logoutBtn');
  const checkerNav = document.getElementById('checkerNav');
  const adminNav = document.getElementById('adminNav');

  if (token && currentUser) {
    authBtn.style.display = 'none';
    logoutBtn.style.display = 'block';
    checkerNav.style.display = 'block';
    if (currentUser.isAdmin) {
      adminNav.style.display = 'block';
    }
  } else {
    authBtn.style.display = 'block';
    logoutBtn.style.display = 'none';
    checkerNav.style.display = 'none';
    adminNav.style.display = 'none';
  }
}

// Auth functions
function toggleAuth() {
  document.getElementById('loginForm').style.display = 
    document.getElementById('loginForm').style.display === 'none' ? 'block' : 'none';
  document.getElementById('signupForm').style.display = 
    document.getElementById('signupForm').style.display === 'none' ? 'block' : 'none';
  document.getElementById('authTitle').textContent = 
    document.getElementById('loginForm').style.display === 'none' ? 'Sign Up' : 'Login';
}

async function handleLogin() {
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value.trim();

  if (!email || !password) {
    showMessage('Please fill all fields', 'error');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.message || 'Login failed', 'error');
      return;
    }

    token = data.token;
    currentUser = data.user;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(currentUser));
    updateNavigation();
    showMessage('Login successful!', 'success');
    setTimeout(() => showChecker(), 1500);
  } catch (err) {
    showMessage('Error: ' + err.message, 'error');
  }
}

async function handleSignup() {
  const username = document.getElementById('signupUsername').value.trim();
  const email = document.getElementById('signupEmail').value.trim();
  const password = document.getElementById('signupPassword').value.trim();
  const phone = document.getElementById('signupPhone').value.trim();

  if (!username || !email || !password || !phone) {
    showMessage('Please fill all fields', 'error');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password, phone })
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.message || 'Signup failed', 'error');
      return;
    }

    token = data.token;
    currentUser = data.user;
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(currentUser));
    updateNavigation();
    showMessage('Signup successful! Welcome!', 'success');
    setTimeout(() => showChecker(), 1500);
  } catch (err) {
    showMessage('Error: ' + err.message, 'error');
  }
}

function logout() {
  token = null;
  currentUser = null;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  updateNavigation();
  showMessage('Logged out successfully', 'success');
  setTimeout(() => showHome(), 1500);
}

// Lottery checker functions
async function checkByMobile() {
  const mobileNumber = document.getElementById('mobileInput').value.trim();

  if (!mobileNumber) {
    showMessage('Please enter a mobile number', 'error');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/lottery/check`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ mobileNumber })
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.message || 'Error checking results', 'error');
      return;
    }

    displayResults(data.results || []);
  } catch (err) {
    showMessage('Error: ' + err.message, 'error');
  }
}

async function checkByTicket() {
  const ticketNumber = document.getElementById('ticketInput').value.trim();

  if (!ticketNumber) {
    showMessage('Please enter a ticket number', 'error');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/lottery/check`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ ticketNumber })
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.message || 'Error checking results', 'error');
      return;
    }

    displayResults(data.results || []);
  } catch (err) {
    showMessage('Error: ' + err.message, 'error');
  }
}

function displayResults(results) {
  const resultContainer = document.getElementById('resultContainer');
  const resultsList = document.getElementById('resultsList');

  if (results.length === 0) {
    resultsList.innerHTML = '<p style="text-align:center; color:#dc3545;">No results found</p>';
    resultContainer.style.display = 'block';
    return;
  }

  let html = '';
  results.forEach(result => {
    const drawDate = new Date(result.drawDate).toLocaleDateString();
    html += `
      <div class="result-card ${result.status === 'lost' ? 'lost' : ''}">
        <div class="result-row">
          <span class="result-label">Ticket Number:</span>
          <span class="result-value">${result.ticketNumber}</span>
        </div>
        <div class="result-row">
          <span class="result-label">Name:</span>
          <span class="result-value">${result.name}</span>
        </div>
        <div class="result-row">
          <span class="result-label">Mobile:</span>
          <span class="result-value">${result.mobileNumber}</span>
        </div>
        <div class="result-row">
          <span class="result-label">Amount:</span>
          <span class="result-value">₹${result.amount}</span>
        </div>
        <div class="result-row">
          <span class="result-label">Draw Date:</span>
          <span class="result-value">${drawDate}</span>
        </div>
        <div class="result-row">
          <span class="result-label">Status:</span>
          <span class="result-value" style="color: ${result.status === 'won' ? '#28a745' : '#dc3545'}; font-weight: bold;">
            ${result.status.toUpperCase()}
          </span>
        </div>
      </div>
    `;
  });

  resultsList.innerHTML = html;
  resultContainer.style.display = 'block';
}

// Admin functions
async function addLotteryResult() {
  const ticketNumber = document.getElementById('adminTicket').value.trim();
  const mobileNumber = document.getElementById('adminMobile').value.trim();
  const name = document.getElementById('adminName').value.trim();
  const amount = document.getElementById('adminAmount').value.trim();
  const drawDate = document.getElementById('adminDate').value;

  if (!ticketNumber || !mobileNumber || !name || !amount || !drawDate) {
    showMessage('Please fill all fields', 'error');
    return;
  }

  try {
    const response = await fetch(`${API_URL}/admin/add-result`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        ticketNumber,
        mobileNumber,
        name,
        amount: parseFloat(amount),
        drawDate
      })
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.message || 'Error adding result', 'error');
      return;
    }

    showMessage('Lottery result added successfully!', 'success');
    document.getElementById('adminTicket').value = '';
    document.getElementById('adminMobile').value = '';
    document.getElementById('adminName').value = '';
    document.getElementById('adminAmount').value = '';
    document.getElementById('adminDate').value = '';
  } catch (err) {
    showMessage('Error: ' + err.message, 'error');
  }
}

async function getAllResults() {
  try {
    const response = await fetch(`${API_URL}/admin/all-results`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.message || 'Error fetching results', 'error');
      return;
    }

    const resultsList = document.getElementById('adminResultsList');
    if (data.results.length === 0) {
      resultsList.innerHTML = '<p>No results found</p>';
      return;
    }

    let html = '';
    data.results.forEach(result => {
      const drawDate = new Date(result.drawDate).toLocaleDateString();
      html += `
        <div class="result-card">
          <div class="result-row">
            <span class="result-label">Ticket:</span>
            <span class="result-value">${result.ticketNumber}</span>
          </div>
          <div class="result-row">
            <span class="result-label">Name:</span>
            <span class="result-value">${result.name}</span>
          </div>
          <div class="result-row">
            <span class="result-label">Mobile:</span>
            <span class="result-value">${result.mobileNumber}</span>
          </div>
          <div class="result-row">
            <span class="result-label">Amount:</span>
            <span class="result-value">₹${result.amount}</span>
          </div>
          <div class="result-row">
            <span class="result-label">Status:</span>
            <span class="result-value">${result.status}</span>
          </div>
          <button class="btn btn-danger" onclick="deleteResult('${result._id}')">Delete</button>
        </div>
      `;
    });

    resultsList.innerHTML = html;
  } catch (err) {
    showMessage('Error: ' + err.message, 'error');
  }
}

async function deleteResult(resultId) {
  if (!confirm('Are you sure you want to delete this result?')) return;

  try {
    const response = await fetch(`${API_URL}/admin/result/${resultId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.message || 'Error deleting result', 'error');
      return;
    }

    showMessage('Result deleted successfully!', 'success');
    getAllResults();
  } catch (err) {
    showMessage('Error: ' + err.message, 'error');
  }
}

async function getAllUsers() {
  try {
    const response = await fetch(`${API_URL}/admin/users`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.message || 'Error fetching users', 'error');
      return;
    }

    const usersList = document.getElementById('adminUsersList');
    if (data.users.length === 0) {
      usersList.innerHTML = '<p>No users found</p>';
      return;
    }

    let html = '<div class="users-grid">';
    data.users.forEach(user => {
      html += `
        <div class="user-card">
          <h4>${user.username}</h4>
          <div class="user-info">📧 ${user.email}</div>
          <div class="user-info">📱 ${user.phone}</div>
          ${user.isAdmin ? '<div class="admin-badge">Admin</div>' : ''}
        </div>
      `;
    });
    html += '</div>';

    usersList.innerHTML = html;
  } catch (err) {
    showMessage('Error: ' + err.message, 'error');
  }
}

// Utility function
function showMessage(message, type) {
  const messageDiv = document.createElement('div');
  messageDiv.className = `message ${type}`;
  messageDiv.textContent = message;
  document.body.insertBefore(messageDiv, document.body.firstChild);
  setTimeout(() => messageDiv.remove(), 4000);
}
